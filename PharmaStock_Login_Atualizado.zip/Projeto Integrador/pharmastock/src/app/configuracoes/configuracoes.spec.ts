import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Configuracoes } from './configuracoes';

describe('Configuracoes', () => {
  let component: Configuracoes;
  let fixture: ComponentFixture<Configuracoes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Configuracoes],
    }).compileComponents();

    fixture = TestBed.createComponent(Configuracoes);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
