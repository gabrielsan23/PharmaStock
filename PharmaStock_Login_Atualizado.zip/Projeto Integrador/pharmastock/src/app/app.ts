import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

type VisaoCores = 'normal' | 'protanopia' | 'deuteranopia' | 'tritanopia';

@Component({
  imports: [RouterOutlet, RouterLink, RouterLinkActive, FormsModule, CommonModule],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  protected readonly title = 'pharmastock';
  menuAcessibilidadeAberto = false;
  temaEscuro = false;
  visaoCores: VisaoCores = 'normal';
  altoContraste = false;
  fonteAmpliada = false;
  reduzirAnimacoes = false;

  autenticado = false;
  usuario = '';
  senha = '';
  mostrarSenha = false;
  erroLogin = '';
  unidade = 'Hospital Unit A — Matriz São Paulo';
  modulo = 'Dashboard Geral (WMS/ERP)';
  lembrar = true;

  constructor(private router: Router) {
    this.autenticado = sessionStorage.getItem('pharmastock-autenticado') === 'true';
    this.carregarPreferencias();
    this.aplicarPreferencias();
  }

  entrar(): void {
    if (this.usuario.trim().toLowerCase() === 'acesso' && this.senha === '12345') {
      this.erroLogin = '';
      this.autenticado = true;
      sessionStorage.setItem('pharmastock-autenticado', 'true');
      this.router.navigateByUrl('/dashboard');
    } else {
      this.erroLogin = 'Usuário ou senha incorretos. Verifique suas credenciais.';
    }
  }

  preencherAcesso(): void {
    this.usuario = 'acesso';
    this.senha = '12345';
    this.erroLogin = '';
  }

  mostrarAjudaSenha(): void {
    this.erroLogin = 'Acesso de demonstração: utilize o usuário "acesso" e a senha "12345".';
  }

  sair(): void {
    sessionStorage.removeItem('pharmastock-autenticado');
    this.autenticado = false;
    this.usuario = '';
    this.senha = '';
    this.router.navigateByUrl('/');
  }

  alternarMenuAcessibilidade(): void {
    this.menuAcessibilidadeAberto = !this.menuAcessibilidadeAberto;
  }

  alternarTema(): void {
    this.temaEscuro = !this.temaEscuro;
    this.aplicarPreferencias();
    this.salvarPreferencias();
  }

  alterarVisaoCores(evento: Event): void {
    this.visaoCores = (evento.target as HTMLSelectElement).value as VisaoCores;
    this.aplicarPreferencias();
    this.salvarPreferencias();
  }

  alternarAltoContraste(): void {
    this.altoContraste = !this.altoContraste;
    this.aplicarPreferencias();
    this.salvarPreferencias();
  }

  alternarFonte(): void {
    this.fonteAmpliada = !this.fonteAmpliada;
    this.aplicarPreferencias();
    this.salvarPreferencias();
  }

  alternarAnimacoes(): void {
    this.reduzirAnimacoes = !this.reduzirAnimacoes;
    this.aplicarPreferencias();
    this.salvarPreferencias();
  }

  restaurarAcessibilidade(): void {
    this.visaoCores = 'normal';
    this.altoContraste = false;
    this.fonteAmpliada = false;
    this.reduzirAnimacoes = false;
    this.aplicarPreferencias();
    this.salvarPreferencias();
  }

  private carregarPreferencias(): void {
    try {
      const salvo = localStorage.getItem('pharmastock-preferencias');
      if (!salvo) return;
      const preferencias = JSON.parse(salvo);
      this.temaEscuro = preferencias.temaEscuro === true;
      this.visaoCores = ['normal', 'protanopia', 'deuteranopia', 'tritanopia'].includes(preferencias.visaoCores)
        ? preferencias.visaoCores : 'normal';
      this.altoContraste = preferencias.altoContraste === true;
      this.fonteAmpliada = preferencias.fonteAmpliada === true;
      this.reduzirAnimacoes = preferencias.reduzirAnimacoes === true;
    } catch {
      try { localStorage.removeItem('pharmastock-preferencias'); } catch { /* armazenamento indisponível */ }
    }
  }

  private salvarPreferencias(): void {
    try {
      localStorage.setItem('pharmastock-preferencias', JSON.stringify({
        temaEscuro: this.temaEscuro,
        visaoCores: this.visaoCores,
        altoContraste: this.altoContraste,
        fonteAmpliada: this.fonteAmpliada,
        reduzirAnimacoes: this.reduzirAnimacoes,
      }));
    } catch { /* O sistema continua funcionando mesmo sem armazenamento local. */ }
  }

  private aplicarPreferencias(): void {
    const raiz = document.documentElement;
    raiz.setAttribute('data-bs-theme', this.temaEscuro ? 'dark' : 'light');
    raiz.setAttribute('data-vision', this.visaoCores);
    raiz.classList.toggle('high-contrast', this.altoContraste);
    raiz.classList.toggle('large-font', this.fonteAmpliada);
    raiz.classList.toggle('reduce-motion', this.reduzirAnimacoes);
  }
}
